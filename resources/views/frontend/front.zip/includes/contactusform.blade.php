<!-- Header Search -->
<div class="contact-form-model-wrap text-center">
    <span class="model-close"><i class="fa fa-times"></i></span>
    <div class="contact-form-inner">
        <div class="sec-title text-center">
            <div class="sec-title-inner">
                <span>Have Question</span>
                <h3>Send Message</h3>
            </div>
        </div>
        <div class="contact-form text-center">
            <form>
                <div class="row mrg20">
                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <input type="text" placeholder="Name">
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <input type="text" placeholder="Phone">
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <input type="email" placeholder="Email">
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <input type="text" placeholder="Subject">
                    </div>
                    <div class="col-md-12 col-sm-12 col-lg-12">
                        <textarea placeholder="Message"></textarea>
                        <button class="thm-btn brd-rd40" type="submit">Contact Us</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div><!-- Contact Form Model Wrap -->
