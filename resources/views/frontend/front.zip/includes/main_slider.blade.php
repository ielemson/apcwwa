<section class ="owl-curve-green">
    <div class="gap no-gap">
        <div class="featured-area-wrap text-center">
            {{-- <a class="contact-btn" href="#" title=""><i class="flaticon-comment"></i>Contact Us</a> --}}
            <div class="featured-area2 owl-carousel">
                <div class="featured-item style2" style="background-image: url(frontend/images/slider/slider-1.jpg);">
                    <div class="featured-cap">
                  
                        <h3>Our Core Principle</h3>
                        <span>We do not root for any individual. We root for the institution of Party and Government.</span>
                       
                    </div>
                </div>
                <div class="featured-item style2" style="background-image: url(frontend/images/slider/slider-4_1200x600.jpg);">
                    <div class="featured-cap">
            
                        <h3>His Excellency</h3>
                        <span>Muhammadu Buhari</span>
                       
                    </div>
                </div>
                <div class="featured-item style2" style="background-image: url(frontend/images/slider/slider-5.jpeg);">
                    <div class="featured-cap">
                        
                        <h3>APC</h3>
                        <span>All Progressive Congress</span>
                        
                    </div>
                </div>
               
            </div>
        </div><!-- Featured Area Wrap -->
    </div>
</section>